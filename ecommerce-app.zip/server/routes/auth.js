
const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const conn = require('../db');
const router = express.Router();

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  conn.query('SELECT * FROM users WHERE email = ?', [email], async (err, result) => {
    if (err) return res.status(500).json(err);
    if (result.length === 0) return res.status(401).json("User not found");

    const user = result[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(403).json("Incorrect password");

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.cookie('token', token, { httpOnly: true }).json("Logged in");
  });
});

router.get('/logout', (req, res) => {
  res.clearCookie('token').json("Logged out");
});

module.exports = router;
